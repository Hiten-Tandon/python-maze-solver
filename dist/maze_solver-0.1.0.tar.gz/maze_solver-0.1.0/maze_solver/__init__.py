import __main__
import window
